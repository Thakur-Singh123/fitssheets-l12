<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        api: __DIR__.'/../routes/api.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {

        $middleware->alias([
            'admin' => \App\Http\Middleware\Admin::class,
            'user' => \App\Http\Middleware\User::class,
            'casemanager' => \App\Http\Middleware\CaseManager::class,
            'supervisor' => \App\Http\Middleware\Supervisor::class,
            'api.auth.check' => \App\Http\Middleware\ApiAuthCheck::class,
            'api.auth' => \App\Http\Middleware\ApiAuth::class,
            'role' => \App\Http\Middleware\CheckRole::class,
            'api.response.auth' => \App\Http\Middleware\ApiResponseAuth::class,
        ]);

    })
    ->withExceptions(function (Exceptions $exceptions): void {
        //
    })->create();